const clock = document.getElementById('clock');
const content = document.getElementById('text');
const pesan = document.getElementById('pesan');
const credit = document.getElementById('credit');
const time = new Date();
const hour = time.getHours();

credit.textContent = 'made by yukiteru with love for matsuno';

//
//  Jam 
//  

function work() {
    const time = new Date();
    var hour = time.getHours().toString();
    var minute = time.getMinutes().toString();
    var second = time.getSeconds().toString();


    if (hour.length < 2) {
        hour = '0' + hour;
    }

    if (minute.length < 2) {
        minute = '0' + minute;
    }

    if (second.length < 2) {
        second = '0' + second;
    }

    var final = hour + ':' + minute + ':' + second;

    clock.textContent = final;
}
setInterval(work, 1000);

//
//  Deteksi jam dan ubah kelas
//


if (hour > 18) {
    $(document).ready(function () {
        $('section').toggleClass('background night');
    })
    text = "Selamat malam 😴"

} else if (hour > 14) {
    $(document).ready(function () {
        $('section').toggleClass('background noon');
    })
    text = "Selamat sore 😄"

} else if (hour > 09) {
    $(document).ready(function () {
        $('section').toggleClass('background day');
    })
    text = "Selamat Siang 😁"

} else if (hour > 1) {
    $(document).ready(function () {
        $('section').toggleClass('background morning');
    })
    text = "Selamat Pagi 😆"
}
var i = 0,
    text;

setTimeout(
    function typing() {
        setTimeout(2000);
        if (i < text.length) {
            content.innerHTML += text.charAt(i);
            i++;
            setTimeout(typing, 50);
        }
    }, 500);

var minutes = time.getMinutes();

if (minutes > 50) {
    teks = ["Cinta tidak akan tumbuh hanya karena terbiasa. karena cinta adalah perasaan, bukan kebiasaan.", "Karena sejatinya menjadi sempurna aku tak mampu. maka maafkan aku yang selalu salah dimatamu", "tidak ada perasaan yang salah, hanya saja kita yang terlalu berharap pada orang yang salah", "Ingatlah kebaikan seseorang ketika kamu marah padanya, tidak ada manusia sempurna yang selalu baik, dia juga bisa salah", "Jangan menghakimi seseorang hanya karena masa lalunya tidak baik, setiap orang pernah salah, begitu pula dirimu yang tak selalu benar."]
} else if (minutes > 40) {
    teks = ["Ingatlah, jika kamu berada di jalan yang salah Tuhan selalu mengijinkan mu untuk kembali ke jalan yang benar.", "Kamulah yang terbaik, tetaplah jadi yang terbaik.", "kejujuran yang menjadi kebiasaan membawa kebanggaan. kebohongan yang menjadi kebiasaan membawa kesengsaraan.", "Bermimpilah dalam hidup, bukan hidup dalam mimpi", "Menangis bukan berarti lemah, jangan berfikir kamu sendiri, kamu tidak akan pernah tau ada berapa banyak orang yang membutuhkan mu.", "Tidak perlu menjadi sempurna untuk menjadi bahagia.", "Jangan menangis karena itu telah usai, namun tersenyumlah karena itu telah terjadi.", "Orang berjiwa besar selalu memiliki dua hati yaitu hati yang selalu menangis dan bersabar.", "Orang baik adalah yang selalu malu jika perkataan nya melebihi perbuatanya."]
} else if (minutes > 44) {
    teks = ["Jangan habiskan hari ini untuk memikirkan hari esok, berusahalah dan lakukan hal yang menurutmu terbaik.", "Hentikan kebiasaan mu membandingkan kekurangan mu dengan orang lain.", "Hidup ini sebenarnya indah, jadi jangan merenung tetapi rasakan keindahanya.", "Jangan selalu bergantung kepada orang lain karena bayanganmu sendiri dapat meninggalkan mu ketika kamu di dekat kegelapan.", "Relakan jika memang harus berakhir, karena akhir sebuah kisah adalah sebuah awal dari kisah yang baru.", "Kesederhanaan memberikan anda ruang untuk berpikir lebih dalam atas makna dari kehidupan.", "Pikirkanlah kebaikan orang yang anda benci niscanya benci akan berubah menjadi memaklumi.", "Aku tidak berusaha menjadi lebih baik dari orang lain. aku berusaha menjadi lebih baik dari diriku sendiri.", "Kegagalan disebabkan oleh dua hal, yakni orang yang selalu berfikir tanpa bertindak dan orang yang selalu bertindak tanpa berfikir."]
} else if (minutes > 35) {
    teks = ["bayak hal yang dapat menjatuhkanmu, tapi satu-satunya yang dapat benar-benar menjatuhkanmu adalah dirimu sendiri.", "Terkadang kebiasaan buruk bukan berasal dari keinginan pribadi namun dari lingkungan dan media yang ada, jauhi lingkungan yang buruk.", "Sebaik baiknya perkataan itu adalah yang sedikit tapi memberikan kejelasan.", "Jangan selalu membicarakan kejelekan orang lain karena yang sejatinya jelek adalah orang yang membicarakan nya.", "Masa depan bukanlah apa yang kamu tuju namun apa yang kamu ciptakan.", "Senyuman disetiap hariku bukan karena hidupku yang sempurna, tetapi karena aku bersyukur atas apa yang terjadi."]
} else if (minutes > 29) {
    teks = ["Jika ia menghianatimu maafkanlah, namun jangan bodoh untuk dapat mempercayainya lagi.", "Kamu bisa karena terbiasa, terbiasa karena kemauan.", "Cara terbaik menghentikan kebiasaan buruk adalah jangan pernah memulai nya.", "Bagi orang yang tidak menyukai mu, selalu ada celah untuk terlihat salah.", "mimpi menjadi kenyataan adalah hasil dari perbuatan."]
} else if (minutes > 24) {
    teks = ["Yang menurutmu buruk belum tentu itu buruk, yang baik belum tentu baik.", "Menghargai jauh lebih penting daripada memaksakan.", "Alangkah indahnya jika kebaikan bukan hanya sekedar kewajiban, melainkan kebiasaan.", "Keadaan masih akan tetap sama selama kebiasaan masih yang lama.", "Biasakanlah yang benar, bukan membenarkan kebiasaan."]
} else if (minutes > 19) {
    teks = ["Apa salah jika aku lelah menjadi orang yang mengalah?.", "Pergi tak selamanya pedih karena bertahan tak selamanya indah", "Sebanyak apapun salah, kata maaf selalu datang.", "Jika tidak bisa menjadi yang terbaik jadilah yang dapat membahagiakan.", "Iklash itu bukan diucapkan tetapi dipraktikan tanpa mengharap imbalan."]
} else if (minutes > 14) {
    teks = ["Terkadang untuk melakukan hal yang benar, kita harus bersabar dan menrelakan apa yang kita inginkan.", "Susah berfikir logis, namun kadang hati ini mengalahkan logika ku.", "Dan jangan lupa ajarkanlah mereka memahami betapa dalam dan luasnya samudra.", "Ada masa dimana semua yang kamu lakukan selalu salah dan pedihnya niat baik pun terlihat jelek.", "Sadar akan kekurangan lebih baik daripada bangga akan kelebihan."]
} else if (minutes > 09) {
    teks = ["Aku akan selalu berusaha iklash dalam kehilangan dan tersenyum dari suatu kesakitan.", "Jika kamu heran kenapa selalu salah dimatanya mungkin  dia adalah oposisi", "Ketika kamu terobsesi mengejar apa yang bukan untukmu, kamu akan selalu menemukan sesuatu yang salah dengan yang kamu miliki. ", "Jangan merasa paling sempurna, sehingga orang lain selalu salah.", "maju dan menerima hasilnya lebih baik daripada ragu untuk memulai."]
} else if (minutes > 04) {
    teks = ["lebih baik mengerti sedikit daripada salah mengerti.", "cinta itu tidak hanya saling menyayangi namun juga saling mengerti.", "Istirahatlah aku tahu kamu lelah bersandiwara.", "Karena kadang di suatu titik, diam adalah pilihan terbaik daripada berbicara namun selalu salah dimatanya.", "Terkadang aku berfikir diam dan sendiri itu lebih baik."]
} else {
    teks = ["Rindu kebiasaan adalah hal terpilu dari kehilangan.", "Berhentilah kepada seseorang yang bisa mengehentikan kebiasaan mu berfikir dua kali", "Salah satu cara membuat pasangan kita sempurna adalah dengan tidak membandingkanya dengan siapapun", "Jika niat pada awalnya sudah salah, langkah selanjutnya akan selalu salah"]
}

class TypeWriter {
    constructor(txtElement, wait = 3000) {
        this.txtElement = txtElement;
        this.words = teks;
        this.txt = '';
        this.wordIndex = 0;
        this.wait = parseInt(wait, 1000);
        this.type();
        this.isDeleting = false;
    }

    type() {
        const current = this.wordIndex % this.words.length;
        const fullTxt = this.words[current];

        if (this.isDeleting) {
            this.txt = fullTxt.substring(0, this.txt.length - 1);
        } else {
            this.txt = fullTxt.substring(0, this.txt.length + 1);
        }

        this.txtElement.innerHTML = `<span class="txt">${this.txt}</span>`;

        let typeSpeed = 50;

        if (this.isDeleting) {
            typeSpeed /= 8;
        }

        if (!this.isDeleting && this.txt === fullTxt) {
            typeSpeed = 5000;
            this.isDeleting = true;
        } else if (this.isDeleting && this.txt === '') {
            this.isDeleting = false;
            this.wordIndex++;
            typeSpeed = 1500;
        }

        setTimeout(() => this.type(), typeSpeed);
    }
}

document.addEventListener('DOMContentLoaded', init);

function init() {
    const txtElement = document.querySelector('.txt-type');
    const words = JSON.parse(txtElement.getAttribute('data-words'));
    const wait = txtElement.getAttribute('data-wait');
    new TypeWriter(txtElement, words, wait);
}
